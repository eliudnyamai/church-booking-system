function openCity(evt, cityName) {
    // Declare all variables
    var i, tabcontent, tablinks;
  
    // Get all elements with class="tabcontent" and hide them
    tabcontent = document.getElementsByClassName("tabcontent");
    for (i = 0; i < tabcontent.length; i++) {
      tabcontent[i].style.display = "none";
    }
  
    // Get all elements with class="tablinks" and remove the class "active"
    tablinks = document.getElementsByClassName("tablinks");
    for (i = 0; i < tablinks.length; i++) {
      tablinks[i].className = tablinks[i].className.replace(" active", "");
    }
  
    // Show the current tab, and add an "active" class to the button that opened the tab
    document.getElementById(cityName).style.display = "flex";
    evt.currentTarget.className += " active";
  }
        // $(document).ready(function(){
        //   feedback=$('#feedback')
        //    button=document.getElementById("insert_admin").name;
        //     $( "#admin-form" ).submit(function( event ) {
        //       event.preventDefault();
        //       $('#insert_admin').attr('value', 'Sending...');
        //       feedback.empty().text('Sending');
              
        //     post=$.post( 'actions.php',$(this).serialize()+"&"+button+"=true", )
        //     .done(function(){
        //                       $('#insert_admin').attr('value', 'created');
        //                       setTimeout(function(){
        //                         $('#insert_admin').attr('value', 'create another');
        //                         feedback.empty().text('');
        //                          }, 3000);

        //     })
        //     .fail(function(){
        //       feedback.empty().text('An error occured, Try again');
        //     })
        //     .always(function(data){
        //       feedback.empty().text(data);
        //     });  
        //       });
        //   });
       
    function sendAjaxRequest( form, button,page) {
      
        feedback=$('.feedback');
      $('#'+form).submit(function( e ) {
           e.preventDefault();
           $('#'+button).attr('value', 'Sending...');
              feedback.empty().text('Sending');
              serialdata=$(this).serialize();
            post=$.post( page,$(this).serialize()+"&"+button+"=true", )
            .done(function(){
                              $('#'+button).attr('value', 'created');
                              setTimeout(function(){
                                $('#'+button).attr('value', 'create another');
                                feedback.empty().text('Record created successfully reload to see it');
                                 }, 6000);
                                
                                 return true;
            })
            .fail(function(){
              feedback.empty().text('An error occured, Try again');
              return false;
            })
            .always(function(data){
              feedback.text(data);
            });  
      });
  }
  function sendPdfRequest(form, button,page) {
    feedback=$('.feedback');
    $('#'+form).submit(function( e ) {
       
      e.preventDefault();
      
      $('#'+button).attr('value', 'Sending...');
         serialdata=$(this).serialize();
       post=$.post( page,$(this).serialize()+"&"+button+"=true", )
       .done(function(){
        setTimeout(function(){
          feedback.empty().text('Booking successful');
           }, 1000);
         //location.reload();
        
      return true;
       })
       .fail(function(){
         return false;
       })
       .always(function(data){
       
       });  
 });
  }
  $('#insert_admin').one('click',function() {
   
    sendAjaxRequest( 'admin-form', 'insert_admin','actions.php');
  });
  $('#insert-speaker').one('click',function() {
  
    sendAjaxRequest( 'speaker-form', 'insert-speaker','actions.php');
  });
  $('#insert-session').one('click',function() {

    sendAjaxRequest( 'session-form', 'insert-session','action.php');
  });
  $('#sessionModal').on('show.bs.modal', function (event) {
    var button = $(event.relatedTarget) // Button that triggered the modal
    var session = button.data('whatever') // Extract info from data-* attributes
    $('#sessionNo').attr('value', session);
    var modal = $(this)
    modal.find('.modal-title').text('Provide your names to book session' + session)
  });
  $('#modalButton').one('click',function() {
        sendPdfRequest( 'booking-form', 'modalButton','../admin/actions.php');
  });
  $('#sessionModal').on('hide.bs.modal', function (event) {
    location.reload(true);
  });



   