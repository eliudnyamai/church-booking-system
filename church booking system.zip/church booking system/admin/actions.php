<?php
include 'functions.php';
if(isset($_POST['insert_admin'])){
    if(isset($_POST['f_name'])){
         $firstname=$_POST['f_name'];
    }
    if(isset($_POST['s_name'])){
        $lastname=$_POST['s_name'];
     }
     if(isset($_POST['pwd'])){
        $pwd=$_POST['pwd'];
     }
     if(isset($_POST['email'])){
         $email=$_POST['email'];
     }
     if(isset($_POST['confirm_pwd'])){
        $confirm_pwd=$_POST['confirm_pwd'];
     }
     if ($pwd===$confirm_pwd) {
        $table="admin";
     $data=array("firstname"=>$firstname,"lastname"=>$lastname,"email"=>$email ,"password"=>$pwd,"admin_id"=>NULL);
     insert_data($table,$data);  
     }
     else{
         exit('passwords must match');
     }
    
}
if (isset($_POST['insert-speaker'])) {
    if(isset($_POST['f_name'])){
        $firstname=$_POST['f_name'];
   }
   if(isset($_POST['l_name'])){
       $lastname=$_POST['l_name'];
    }
    $table="speakers";
     $data=array("first_name"=>$firstname,"last_name"=>$lastname);
     insert_data($table,$data);  
}
if (isset($_POST['insert-session'])) {
    if(isset($_POST['s_no'])){
      $s_no=$_POST['s_no'];
   }
   if(isset($_POST['speaker'])){
    $speaker=$_POST['speaker'];
 }
 if(isset($_POST['start-time'])){
    $start_time=$_POST['start-time'];
 }
 if(isset($_POST['end-time'])){
    $end_time=$_POST['end-time'];
 }
 if(isset($_POST['topic'])){
     $topic=$_POST['topic'];
 }
 $table="session";
 $data=array("session_id"=>NULL, "speaker"=>$speaker,"topic"=>$topic,"start_time"=>$start_time,
 "end_time"=>$end_time,"session_number"=>$s_no);
 insert_data($table,$data);  
}
if (isset($_POST['session_no'])) {
 $s_no=$_POST['session_no'];
 if(isset($_POST['f_name'])){
   $firstname=$_POST['f_name']; 
 }
 if(isset($_POST['l_name'])){
   $lastname=$_POST['l_name']; 
 }
 $table="booking";
 $data=array("booking_id"=>NULL, "first_name"=>$firstname,"last_name"=>$lastname,"session_id"=>$s_no);
 if(insert_data($table,$data)){
   $table="session";
   $column="*";
   $condition=array("session_number"=>$s_no);
   $session=select_data($table,$column,$condition); 
 }  
}
if(isset($_POST['login_admin'])){
   $table="admin";
   $column="*";
   $email="eliudmitau@gmail.com";
   $password='ijhjth';
   $condition=array('email'=>$email);
   $condition2=array('password'=>$password);
   $data=select_data($table,$column,$condition,$condition2);
   if(count($data)>0){
    $_SESSION["login"]=$data[0]['email'];
    echo $_SESSION["login"];
    header("Location: index.php");
   }
}
