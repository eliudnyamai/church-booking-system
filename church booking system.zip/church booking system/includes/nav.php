<nav id="navbar" class="navbar  sticky-top  p-0 h3 navbar-light custom-navbar navbar-expand-lg  ">
        <a class="navbar-brand  h1" href="#">
            <img class="logo  border-0" src="../images/logo.gif" alt="">
        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse flex-row-reverse " id="navbarNav">
            <ul class="navbar-nav">
                <li class="nav-item mx-auto">
                    <a class="nav-link link text-white  " href="../homepage/">Booking</a>
                </li>
                <li class="nav-item mx-auto">
                    <a class=" text-white nav-link link" href="../admin/">Admin</a>
                </li>
            </ul>   
    </div>     
    </nav>