<br> <br>
       <div id="footer" class="footer fixed-bottom  text-white bg-dark">
         <div id="span"></div>
         <br>
           &copy;Kasarani AIC <script>document.write(new Date().getFullYear())</script>
           made with <i class="fa fa-heart"></i> by <a target="_blank" href="https://eliudmakes.com/">Elliot</a>
       </div> 
  
       <script
  src="https://code.jquery.com/jquery-3.5.1.min.js"
  integrity="sha256-9/aliU8dGd2tb6OSsuzixeV4y/faTqgFtohetphbbj0="
  crossorigin="anonymous"></script>
      <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
    <script src="../js/script.js"></script> 

<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.4/umd/popper.min.js"></script>

