<?php
session_start();
include 'database.php';
function insert_data($table, $datas = array()){
$database=new Connection();
$db=$database->openConnection();
    foreach($datas as $key => $value) {
        $field []= $key;
        $data []= $value;
    }

    $sql = "INSERT INTO ".$table." (";
    $i = 0;
    for($f=0; $f < count($field); $f++)
    {
        $sql .= ++$i === count($field) ? $field[$f] : $field[$f].", ";
    }
    $sql .= ") VALUES (";
    for($d=0; $d < count($data); $d++)
    {
        $sql .= end($data) === $data[$d] ? (is_string($data[$d]) ? $db->quote($data[$d]) : (is_null($data[$d]) ? "NULL" : $data[$d])) : (is_string($data[$d]) ? $db->quote($data[$d])."," : (is_null($data[$d]) ? "NULL," : $data[$d].","));
    }
    $sql .= ")";
     try {
        $db->exec($sql);
        return true;
        $database->closeConnection();
     } catch (PDOException $e) {
        echo "There is some problem during insertion: " . $e->getMessage();
        return false;
     }
}
function select_data($table, $column, $condition=array(), $condition2=array()){
    $database=new Connection();
    $db=$database->openConnection();
    foreach($condition as $key=> $value) {
        $conditionName= $key;
        $conditionValue= $value;
    } 
    if(count($condition)==0&&count($condition2)==0){
        $sql="SELECT $column FROM ".$table."";
    }
    else if(count($condition)>0&&count($condition2)==0){
        $sql="SELECT $column FROM ".$table." WHERE `$table`.`$conditionName`='$conditionValue'";
    }  
    elseif (count($condition2)>0) {
        foreach($condition2 as $key=> $value) {
            $condition2Name= $key;
            $condition2Value= $value;
        } 
        $sql = "SELECT * FROM `$table` WHERE `$conditionName` LIKE '$conditionValue' AND `$condition2Name` LIKE '$condition2Value'";
    }
   

    try {
        $data=$db->query($sql);
        $data=$data->fetchAll();
        return $data;
        $database->closeConnection();
     } catch (PDOException $e) {
         echo $sql;
        echo "There is some problem during selection: " . $e->getMessage();
        return false;
     }
}
function auth(){
    
}